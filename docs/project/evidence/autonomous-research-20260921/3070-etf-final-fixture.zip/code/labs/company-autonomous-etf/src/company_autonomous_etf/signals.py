"""The seven registered formulas over the original P11 eligible cross-section."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import engine

LAB_ROOT = Path(__file__).resolve().parents[2]
POLICY = json.loads((LAB_ROOT / "policy.json").read_text())
VARIANTS = ("M2", "A25", "A75", "B", "C", "D50", "D75")


def validate_config(value: dict) -> str:
    if (
        not isinstance(value, dict)
        or set(value) != {"schema_version", "variant"}
        or type(value["schema_version"]) is not int
        or value["schema_version"] != 1
        or value["variant"] not in VARIANTS
    ):
        raise engine.DataBlocker("unregistered-candidate-config", {})
    return value["variant"]


def features_asof(frames: dict[str, pd.DataFrame], cutoff, variant: str) -> pd.DataFrame:
    """Reconstruct every feature and prior score from prefixes; no persistent score cache."""
    if variant not in VARIANTS:
        raise engine.DataBlocker("unregistered-candidate-config", {})
    out = engine.features_asof(frames, cutoff, POLICY)
    eligible = out[["m1", "m2", "m3"]].notna().all(axis=1)
    history = frames["adj_close"].loc[:cutoff].tail(POLICY["historyObservations"])
    out["eligible"] = eligible
    out["allowed"] = frames["allowed"].loc[:cutoff].iloc[-1]
    out["history_count"] = history.notna().sum()
    for name in ("persistence", "block_persistence", "weighted_persistence", "prior_m2", "score"):
        out[name] = np.nan
    if len(history) == POLICY["historyObservations"]:
        # The same 231 returns as original M2, excluding the last 21 observations.
        formation = np.log(history.where(history > 0)).diff().iloc[1:-21]
        signs = np.sign(formation)
        out["persistence"] = signs.mean().where(eligible)
        blocks = formation.to_numpy().reshape(11, 21, len(history.columns)).sum(axis=1)
        out["block_persistence"] = pd.Series(
            np.sign(blocks).mean(axis=0), index=history.columns
        ).where(eligible)
        weights = np.arange(1, 232)
        out["weighted_persistence"] = (
            signs.mul(weights, axis=0).sum().div(weights.sum()).where(eligible)
        )
        rank_m1 = out.m1.rank(pct=True)
        if variant == "M2":
            out["score"] = out.m2
        elif variant in {"A25", "A75"}:
            weight = {"A25": 0.25, "A75": 0.75}[variant]
            out["score"] = (1 - weight) * rank_m1 + weight * out.persistence.rank(pct=True)
        elif variant in {"B", "C"}:
            field = "block_persistence" if variant == "B" else "weighted_persistence"
            out["score"] = (rank_m1 + out[field].rank(pct=True)) / 2
        else:
            prior_month = pd.Timestamp(cutoff).to_period("M") - 1
            prefix = frames["adj_close"].loc[:cutoff].index
            previous = prefix[prefix.to_period("M") == prior_month]
            if len(previous):
                out["prior_m2"] = engine.features_asof(frames, previous[-1], POLICY).m2
            alpha = {"D50": 0.5, "D75": 0.75}[variant]
            out["score"] = (alpha * out.m2 + (1 - alpha) * out.prior_m2.fillna(out.m2)).where(
                eligible
            )
    out["target_weight"] = engine.targets(out, "score", POLICY).reindex(out.index, fill_value=0)
    return out


def simulate(panel: engine.Panel, variant: str, cost: str) -> dict:
    if cost not in {"base", "stress"}:
        raise engine.DataBlocker("unregistered-cost", {})
    return engine.simulate(
        panel,
        POLICY,
        "score",
        POLICY["costBps"][cost],
        feature_builder=lambda frames, cutoff, _config: features_asof(frames, cutoff, variant),
    )
