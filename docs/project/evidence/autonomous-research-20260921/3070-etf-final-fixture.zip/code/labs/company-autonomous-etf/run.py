#!/usr/bin/env python3
"""Protected, offline JSON producer. Inputs and runtime are pinned by the operator."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from company_autonomous_etf.adapter import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
