"""Offline protocol producer; the operator/worker authenticates the enclosing approval.

This module intentionally has no company, cloud, network or lake-discovery dependency.
It verifies staged bytes and the fixed economic envelope, not execution authorization.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import stat
import sys
from datetime import UTC, date, datetime, time
from pathlib import Path, PurePosixPath

import numpy as np
import pandas as pd

from .engine import DataBlocker, make_panel
from .signals import LAB_ROOT, POLICY, features_asof, simulate, validate_config

LAB_PATH = "labs/company-autonomous-etf"
CONFIG_PATH = f"{LAB_PATH}/configs/candidate.json"
CODE_PATHS = (
    f"{LAB_PATH}/run.py",
    f"{LAB_PATH}/policy.json",
    f"{LAB_PATH}/lineage.json",
    *(
        f"{LAB_PATH}/src/company_autonomous_etf/{name}.py"
        for name in ("__init__", "engine", "signals", "adapter")
    ),
    CONFIG_PATH,
)
INPUT_NAMES = tuple(
    f"{stage}/{name}"
    for stage in ("warmup", "dev")
    for name in ("prices.parquet", "meta.parquet", "snapshot.json")
)


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise DataBlocker(reason, {})


def sha(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n").encode()


def strict_json(content: bytes):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate-json-key")
            result[key] = value
        return result

    def invalid(_value):
        raise DataBlocker("nonfinite-json", {})

    value = json.loads(content, object_pairs_hook=pairs, parse_constant=invalid)
    # JSON's legal exponent syntax can also overflow a binary float.
    try:
        json_bytes(value)
    except ValueError:
        raise DataBlocker("nonfinite-json", {}) from None
    return value


def safe_bytes(root: Path, relative: str) -> bytes:
    path = PurePosixPath(relative)
    require(
        bool(relative)
        and str(path) == relative
        and not path.is_absolute()
        and ".." not in path.parts
        and ".git" not in path.parts
        and "\\" not in relative
        and ":" not in relative
        and all(ord(char) >= 32 and ord(char) != 127 for char in relative),
        "invalid-relative-path",
    )
    current = root
    require(not current.is_symlink(), "symlink-input")
    for part in path.parts:
        current = current / part
        require(not current.is_symlink(), "symlink-input")
    require(stat.S_ISREG(current.stat().st_mode), "input-not-regular-file")
    return current.read_bytes()


def verified_bytes(root: Path, name: str, expected: str) -> bytes:
    require(
        isinstance(expected, str) and bool(re.fullmatch(r"[0-9a-f]{64}", expected)),
        "invalid-file-digest",
    )
    content = safe_bytes(root, name)
    require(sha(content) == expected, "staged-file-hash-mismatch")
    return content


def record_digest(value: dict) -> str:
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode())


def validate_manifest(value: dict, config_path: Path, code_root: Path) -> tuple[dict, str]:
    """Check the frozen envelope; typed ingress and signed approval live outside the sandbox."""
    require(
        set(value)
        == {
            "schema_version",
            "id",
            "kind",
            "mission_id",
            "mission_digest",
            "trial_id",
            "plan_digest",
            "plan",
            "spec",
            "code_files",
            "bundle_sha256",
            "config_path",
            "company_commit",
        },
        "manifest-fields-mismatch",
    )
    spec, plan = value["spec"], value["plan"]
    require(
        type(value["schema_version"]) is int
        and value["schema_version"] == 1
        and value["id"] == POLICY["executionProfile"]
        and value["kind"] == "adaptive_discovery",
        "manifest-version-mismatch",
    )
    require(
        record_digest(spec) == value["mission_digest"]
        and record_digest(plan) == value["plan_digest"]
        and plan["mission_digest"] == value["mission_digest"]
        and plan["trial_id"] == value["trial_id"],
        "manifest-identity-mismatch",
    )
    require(
        spec["kind"] == "strategy" and spec["schema_version"] == 1 and plan["schema_version"] == 1,
        "unsupported-mission-kind",
    )
    development = {"start": POLICY["devStart"], "end": POLICY["devEnd"]}
    require(
        spec["development"] == development == plan["development"]
        and spec["sealed"] == [{"start": POLICY["sealedStart"], "end": POLICY["sealedEnd"]}],
        "mission-date-scope-mismatch",
    )
    require(
        spec["objective"]
        == {
            "metric": POLICY["primaryMetric"],
            "direction": "maximize",
            "unit": POLICY["primaryUnit"],
        },
        "mission-objective-mismatch",
    )
    require(
        type(spec["base_cost_bps"]) in (int, float)
        and type(spec["stress_cost_bps"]) in (int, float)
        and spec["base_cost_bps"] == POLICY["costBps"]["base"]
        and spec["stress_cost_bps"] == POLICY["costBps"]["stress"],
        "mission-cost-mismatch",
    )
    require(
        spec["risk_constraints"] == POLICY["riskConstraints"]
        and type(spec["risk_constraints"][0]["maximum"]) in (int, float),
        "mission-risk-mismatch",
    )
    require(
        spec["code"]["repository"] == plan["repository"] == "quant-lab"
        and spec["code"]["write_paths"] == [CONFIG_PATH]
        and plan["changed_paths"] == [CONFIG_PATH]
        and spec["allowed_changes"] == ["features"],
        "mission-change-scope-mismatch",
    )
    require(
        spec["execution_profile"] == plan["execution_profile"] == POLICY["executionProfile"],
        "mission-profile-mismatch",
    )
    require(
        plan["worker_id"] == spec["resources"]["worker_id"] == "worker"
        and plan["hostname"] == "DESKTOP-5T00NAF"
        and plan["gpu"] == "NVIDIA GeForce RTX 3070",
        "mission-host-mismatch",
    )
    require(
        spec["data"]["lake_id"] == plan["lake_id"]
        and spec["data"]["input_files"] == plan["input_files"]
        and set(plan["input_files"]) == set(INPUT_NAMES),
        "mission-input-scope-mismatch",
    )
    require(
        plan["lake_id"] == POLICY["lakeId"] or plan["lake_id"].startswith("synthetic:"),
        "unregistered-lake",
    )
    require(
        value["config_path"] == CONFIG_PATH
        and set(plan["config_files"]) == {CONFIG_PATH}
        and set(value["code_files"]) == set(CODE_PATHS)
        and value["code_files"][CONFIG_PATH] == plan["config_files"][CONFIG_PATH],
        "code-closure-mismatch",
    )
    # No runtime Git dependency: the outer worker attests exact checkout and ancestry.
    for name, digest in value["code_files"].items():
        verified_bytes(code_root, name, digest)
    require(config_path.absolute() == code_root / CONFIG_PATH, "config-path-mismatch")
    config = strict_json(verified_bytes(code_root, CONFIG_PATH, plan["config_files"][CONFIG_PATH]))
    return value, validate_config(config)


def load_stage(inputs: Path, manifest: dict, stage: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Only the requested three stage files are opened, even when manifest pins all six."""
    require(stage in {"warmup", "dev"}, "unknown-input-stage")
    pins = manifest["plan"]["input_files"]
    blobs = {
        name: verified_bytes(inputs, f"{stage}/{name}", pins[f"{stage}/{name}"])
        for name in ("prices.parquet", "meta.parquet", "snapshot.json")
    }
    snapshot = strict_json(blobs["snapshot.json"])
    start, end = POLICY[f"{stage}Start"], POLICY[f"{stage}End"]
    require(snapshot["start"] == start and snapshot["end"] == end, "snapshot-date-mismatch")
    require(
        snapshot["files"]
        == {name: pins[f"{stage}/{name}"] for name in ("prices.parquet", "meta.parquet")},
        "snapshot-file-map-mismatch",
    )
    require(snapshot["returnBasis"] == POLICY["returnBasis"], "snapshot-return-basis-mismatch")
    fixture = manifest["plan"]["lake_id"].startswith("synthetic:")
    require(snapshot.get("fixture", False) is fixture, "snapshot-fixture-policy-mismatch")
    # Synthetic fixtures cannot impersonate qdata provenance. Production preserves original heads.
    if fixture:
        require(
            snapshot["lake_id"] == manifest["plan"]["lake_id"], "snapshot-fixture-lake-mismatch"
        )
        require(
            snapshot["apiPath"] == "synthetic-panel-generator" and snapshot["sourceHeads"] == {},
            "snapshot-fixture-provenance-mismatch",
        )
    else:
        require(
            set(snapshot["sourceHeads"]) == set(POLICY["sourceEtags"]),
            "snapshot-source-heads-mismatch",
        )
        for name, etag in POLICY["sourceEtags"].items():
            head = snapshot["sourceHeads"][name]
            require(
                head["etag"] == etag
                and isinstance(head["uri"], str)
                and bool(head["uri"])
                and type(head["size"]) is int
                and head["size"] > 0
                and isinstance(head["lastModified"], str)
                and bool(head["lastModified"]),
                "snapshot-source-provenance-mismatch",
            )
        require(
            isinstance(snapshot["apiPath"], str) and bool(snapshot["apiPath"]),
            "snapshot-api-missing",
        )
    for name in ("sourceCodeCommit", "consumerCodeCommit"):
        require(
            isinstance(snapshot[name], str) and bool(re.fullmatch(r"[0-9a-f]{40}", snapshot[name])),
            "snapshot-code-provenance-mismatch",
        )
    require(
        isinstance(snapshot["apiSha256"], str)
        and bool(re.fullmatch(r"[0-9a-f]{64}", snapshot["apiSha256"])),
        "snapshot-api-hash-missing",
    )
    created = datetime.fromisoformat(snapshot["createdAt"])
    require(
        created.tzinfo is not None and created.utcoffset() is not None,
        "snapshot-timestamp-not-aware",
    )
    prices = pd.read_parquet(io.BytesIO(blobs["prices.parquet"]))
    meta = pd.read_parquet(io.BytesIO(blobs["meta.parquet"]))
    for frame in (prices, meta):
        require(
            "date" in frame
            and pd.api.types.is_datetime64_any_dtype(frame.date)
            and frame.date.dt.tz is None
            and frame.date.eq(frame.date.dt.normalize()).all(),
            "snapshot-date-type-mismatch",
        )
    make_panel(prices, meta, start, end)
    return prices, meta


def checked_samples(samples: list[dict]) -> bytes:
    require(bool(samples), "empty-qualification-sample")
    for row in samples:
        require(
            type(row["date"]) is date
            and isinstance(row["observed_at"], datetime)
            and row["observed_at"].utcoffset() is not None,
            "qualification-date-type-mismatch",
        )
        require(
            all(
                type(row[key]) is float and math.isfinite(row[key])
                for key in ("score", "adv20_krw", "target_weight")
            ),
            "nonfinite-qualification-sample",
        )
    serial = [
        {**row, "date": row["date"].isoformat(), "observed_at": row["observed_at"].isoformat()}
        for row in samples
    ]
    content = json_bytes(serial)
    require(strict_json(content) == serial, "qualification-json-roundtrip-mismatch")
    return content


def qualify(manifest: dict, variant: str, inputs: Path) -> dict:
    prices, meta = load_stage(inputs, manifest, "warmup")
    panel = make_panel(prices, meta, POLICY["warmupStart"], POLICY["warmupEnd"])
    samples = []
    # A bounded actual sample of eligible rows; no simulation, costs, equity or returns are read.
    for cutoff in panel.frames["adj_close"].index[-4:]:
        features = features_asof(panel.frames, cutoff, variant)
        for ticker, row in features.loc[features.eligible].head(8).iterrows():
            samples.append(
                {
                    "date": cutoff.date(),
                    "observed_at": datetime.combine(cutoff.date(), time(), UTC),
                    "ticker": ticker,
                    "score": float(row.score),
                    "adv20_krw": float(row.adv20),
                    "target_weight": float(row.target_weight),
                }
            )
    checked_samples(samples)
    try:
        checked_samples([])
    except DataBlocker as exc:
        require(str(exc) == "empty-qualification-sample", "empty-negative-control-failed")
    else:
        raise DataBlocker("empty-negative-control-failed", {})
    try:
        checked_samples([{**samples[0], "score": float("nan")}])
    except DataBlocker as exc:
        require(str(exc) == "nonfinite-qualification-sample", "finite-negative-control-failed")
    else:
        raise DataBlocker("finite-negative-control-failed", {})
    return {
        "schema_version": 1,
        "kind": "adaptive_qualification",
        "trial_id": manifest["trial_id"],
        "plan_digest": manifest["plan_digest"],
        "code_commit": manifest["plan"]["code_commit"],
        "config_files": manifest["plan"]["config_files"],
        "input_files": {
            key: manifest["plan"]["input_files"][key]
            for key in INPUT_NAMES
            if key.startswith("warmup/")
        },
        "sample_count": len(samples),
        "json_dates": [row["date"].isoformat() for row in samples],
        "json_datetimes": [row["observed_at"].isoformat() for row in samples],
        "typed_schema": {
            "date": "date",
            "observed_at": "datetime",
            "ticker": "string",
            "score": "float",
            "adv20_krw": "float",
            "target_weight": "float",
        },
        "primary_unit": POLICY["primaryUnit"],
        "empty_sample_rejected": True,
        "non_finite_rejected": True,
        "json_roundtrip_passed": True,
        "performance_read": False,
        "sealed_read": False,
    }


def return_csv(daily: pd.DataFrame) -> tuple[bytes, list[float]]:
    require(
        not daily.empty
        and daily.date.iloc[0] > pd.Timestamp(POLICY["devStart"])
        and daily.date.iloc[-1] == pd.Timestamp(POLICY["devEnd"]),
        "development-observation-boundary-mismatch",
    )
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, lineterminator="\n")
    writer.writerow(["date", "net_return"])
    writer.writerow([POLICY["devStart"], "0"])
    prior, returns = 1.0, [0.0]
    for row in daily.itertuples():
        value = float(row.equity / prior - 1)
        require(math.isfinite(value) and value >= -1, "invalid-net-return")
        writer.writerow([row.date.date().isoformat(), repr(value)])
        returns.append(value)
        prior = float(row.equity)
    return stream.getvalue().encode(), returns


def evaluate(manifest: dict, variant: str, inputs: Path) -> dict[str, bytes]:
    warmup = load_stage(inputs, manifest, "warmup")
    dev = load_stage(inputs, manifest, "dev")
    panel = make_panel(
        pd.concat([warmup[0], dev[0]], ignore_index=True),
        pd.concat([warmup[1], dev[1]], ignore_index=True),
        POLICY["warmupStart"],
        POLICY["devEnd"],
    )
    outputs, runs, series = {}, {}, {}
    # Both scenarios finish and all held-price/risk checks succeed before any output is written.
    for cost in ("base", "stress"):
        runs[cost] = simulate(panel, variant, cost)
        require(
            all(item["within"] for item in runs[cost]["riskConstraints"]), "risk-constraint-failed"
        )
        outputs[f"returns-{cost}.csv"], series[cost] = return_csv(runs[cost]["daily"])
        daily = runs[cost]["daily"].copy()
        daily["date"] = daily.date.dt.strftime("%Y-%m-%d")
        outputs[f"accounting-{cost}.csv"] = daily.to_csv(index=False, lineterminator="\n").encode()
        for kind, key in (
            ("orders", "orders"),
            ("memberships", "memberships"),
            ("terminal-events", "terminalUses"),
        ):
            outputs[f"{kind}-{cost}.json"] = json_bytes(runs[cost][key])
    # Same initial capital/calendar convention as the independent company report consumer.
    wealth = np.cumprod(1 + np.asarray(series["stress"]))
    years = (
        date.fromisoformat(POLICY["devEnd"]) - date.fromisoformat(POLICY["devStart"])
    ).days / 365.25
    cagr = float(wealth[-1] ** (1 / years) - 1)
    drawdown = float(-(wealth / np.maximum.accumulate(wealth) - 1).min())
    outputs["provenance.json"] = json_bytes(
        {
            "schema_version": 1,
            "variant": variant,
            "return_basis": POLICY["returnBasis"],
            "cash_distributions_included": False,
            "initial_capital_date": POLICY["devStart"],
            "initial_capital": 1.0,
            "fixture": manifest["plan"]["lake_id"].startswith("synthetic:"),
            "lake_id": manifest["plan"]["lake_id"],
            "input_files": manifest["plan"]["input_files"],
        }
    )
    refs = {
        cost: {
            "path": f"returns-{cost}.csv",
            "sha256": sha(outputs[f"returns-{cost}.csv"]),
            "frequency": "daily",
            "unit": "fraction-per-period",
        }
        for cost in runs
    }
    result = {
        "schema_version": 1,
        "kind": "adaptive_result",
        "trial_id": manifest["trial_id"],
        "plan_digest": manifest["plan_digest"],
        "code_commit": manifest["plan"]["code_commit"],
        "metrics": {
            "primary": {
                "metric": POLICY["primaryMetric"],
                "direction": "maximize",
                "unit": POLICY["primaryUnit"],
                "value": cagr,
            },
            "risks": {
                "gross_exposure": max(
                    float(run["daily"].grossWeight.max()) for run in runs.values()
                ),
                "max_drawdown": drawdown,
                "annual_turnover": float(runs["stress"]["daily"].turnover.sum() / years),
            },
            "sample_count": len(series["stress"]),
            "sample_window": manifest["plan"]["development"],
        },
        "base_returns": refs["base"],
        "stress_returns": refs["stress"],
        "output_files": {name: sha(content) for name, content in outputs.items()},
    }
    outputs["result.json"] = json_bytes(result)
    return outputs


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("qualify", "evaluate"))
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        require(
            args.manifest.name == "manifest.json" and args.manifest.parent.name == "__contract__",
            "manifest-mount-layout-mismatch",
        )
        inputs = args.manifest.absolute().parent.parent
        manifest = strict_json(safe_bytes(inputs, "__contract__/manifest.json"))
        manifest, variant = validate_manifest(manifest, args.config, LAB_ROOT.parents[1])
        require(
            not args.output.is_symlink()
            and (
                not args.output.exists()
                or (
                    args.output.is_dir()
                    and all(
                        path.name in {"stdout.log", "stderr.log"}
                        and not path.is_symlink()
                        and path.is_file()
                        for path in args.output.iterdir()
                    )
                )
            ),
            "output-not-empty",
        )
        if args.action == "qualify":
            outputs = {"qualification.json": json_bytes(qualify(manifest, variant, inputs))}
        else:
            outputs = evaluate(manifest, variant, inputs)
        args.output.mkdir(parents=True, exist_ok=True)
        for name, content in outputs.items():
            with (args.output / name).open("xb") as stream:
                stream.write(content)
        return 0
    except DataBlocker as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except (OSError, ValueError, KeyError, TypeError, AttributeError, OverflowError):
        print("invalid-offline-contract-or-input", file=sys.stderr)
        return 2
