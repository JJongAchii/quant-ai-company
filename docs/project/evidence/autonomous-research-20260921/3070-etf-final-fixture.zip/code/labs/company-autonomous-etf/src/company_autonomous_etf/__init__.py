"""Protected offline ETF adapter; candidate files select registered formulas only."""
