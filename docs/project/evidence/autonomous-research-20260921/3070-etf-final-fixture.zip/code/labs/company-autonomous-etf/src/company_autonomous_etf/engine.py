"""Causal monthly signals and a cash-conserving adjusted-unit accounting engine.

The adjusted series is exchange-reference-price adjusted, not a cash-distribution TR.
Neither a missing held valuation nor a disappeared ETF has an invented terminal value.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


class DataBlocker(RuntimeError):
    def __init__(self, reason: str, evidence: dict):
        super().__init__(reason)
        self.evidence = {"reason": reason, **evidence}


@dataclass
class Panel:
    frames: dict[str, pd.DataFrame]
    quality: dict


def make_panel(prices: pd.DataFrame, meta: pd.DataFrame, start: str, end: str) -> Panel:
    """Validate typed daily inputs and retain all historical symbols and missing values."""
    price_columns = ["open", "high", "low", "close", "adj_close", "adj_factor", "value"]
    keys = ["date", "ticker"]
    for name, frame, columns in [
        ("prices", prices, keys + price_columns),
        ("meta", meta, keys + ["is_leveraged", "is_inverse"]),
    ]:
        if frame.empty:
            raise DataBlocker("empty-input", {"dataset": name})
        if set(columns) - set(frame):
            raise DataBlocker("missing-columns", {"dataset": name})
        if not pd.api.types.is_datetime64_any_dtype(frame.date):
            raise DataBlocker("date-not-datetime", {"dataset": name})
        if frame[keys].isna().any().any() or frame.duplicated(keys).any():
            raise DataBlocker("null-or-duplicate-key", {"dataset": name})
        if not frame.ticker.map(lambda v: isinstance(v, str)).all():
            raise DataBlocker("ticker-not-string", {"dataset": name})
        if frame.date.min() < pd.Timestamp(start) or frame.date.max() > pd.Timestamp(end):
            raise DataBlocker("input-outside-allowed-window", {"dataset": name})
    joined = prices.merge(
        meta[keys + ["is_leveraged", "is_inverse"]],
        on=keys,
        how="outer",
        validate="one_to_one",
        indicator=True,
    )
    unmatched = joined.loc[joined._merge != "both", keys + ["_merge"]]
    if not unmatched.empty:
        raise DataBlocker(
            "price-meta-join-mismatch",
            {
                "rows": unmatched.astype(str).head(20).to_dict("records"),
                "count": len(unmatched),
            },
        )
    for col in ["is_leveraged", "is_inverse"]:
        if joined[col].isna().any() or not joined[col].isin([True, False]).all():
            raise DataBlocker("invalid-exposure-flag", {"column": col})
    for col in price_columns:
        if not pd.api.types.is_numeric_dtype(joined[col]):
            raise DataBlocker("price-not-numeric", {"column": col})
        if not np.isfinite(joined[col]).all():
            raise DataBlocker("nonfinite-price-input", {"column": col})
    if (joined[["close", "adj_close", "adj_factor"]] <= 0).any().any():
        raise DataBlocker("nonpositive-close-or-factor", {})
    if not np.allclose(joined.close * joined.adj_factor, joined.adj_close, rtol=1e-9):
        raise DataBlocker("adjusted-price-scale-mismatch", {})
    joined["adj_open"] = joined.open * joined.adj_factor
    joined["allowed"] = (~joined.is_leveraged & ~joined.is_inverse).astype(float)
    # High/low/close are unavailable at the open: quality evidence must not control fills.
    valid = (
        (joined[["open", "high", "low", "close"]] > 0).all(axis=1)
        & (joined.high >= joined[["open", "close", "low"]].max(axis=1))
        & (joined.low <= joined[["open", "close", "high"]].min(axis=1))
    )
    joined.loc[joined.open <= 0, "adj_open"] = np.nan
    fields = ["adj_close", "adj_open", "value", "allowed"]
    frames = {
        field: joined.pivot(index="date", columns="ticker", values=field).sort_index()
        for field in fields
    }
    invalid = joined.loc[~valid, keys + ["open", "high", "low", "close", "volume"]]
    return Panel(
        frames,
        {
            "priceRows": len(prices),
            "metaRows": len(meta),
            "joinedRows": len(joined),
            "sessions": len(frames["adj_close"]),
            "tickers": len(frames["adj_close"].columns),
            "firstDate": str(joined.date.min().date()),
            "lastDate": str(joined.date.max().date()),
            "invalidOpenRows": invalid.assign(date=invalid.date.astype(str)).to_dict("records"),
            "calendarBasis": "union of observed ETF dates; not an external exchange calendar",
        },
    )


def features_asof(frames: dict[str, pd.DataFrame], cutoff, config: dict) -> pd.DataFrame:
    """Only the prefix through cutoff enters eligibility, features, or cross-sectional ranks."""
    history = frames["adj_close"].loc[:cutoff].tail(config["historyObservations"])
    columns = history.columns
    out = pd.DataFrame(index=columns, columns=["m1", "m2", "m3", "adv20"], dtype=float)
    if len(history) < config["historyObservations"]:
        return out
    positive = (np.isfinite(history) & (history > 0)).all(axis=0)
    allowed = frames["allowed"].loc[:cutoff].iloc[-1].eq(1)
    # 253 closes -> 252 daily log returns. Formation returns end at t-21.
    logs = np.log(history.where(history > 0))
    returns = logs.diff()
    momentum = logs.iloc[-1 - config["skipSessions"]] - logs.iloc[0]
    vol = returns.tail(config["volatilityReturns"]).std(ddof=1)
    eligible = positive & allowed & np.isfinite(vol) & (vol > 0)
    formation_sign = np.sign(returns.iloc[1 : -config["skipSessions"]]).mean(axis=0)
    eligible &= np.isfinite(momentum) & np.isfinite(formation_sign)
    traded_value = frames["value"].loc[:cutoff].tail(config["advSessions"])
    adv = traded_value.mean()
    if config.get("minimumAdv20Krw") is not None:
        # A genuine zero is an observation. Missing/invalid values cannot shorten
        # the denominator or turn a partially observed window into a liquid ETF.
        complete = (np.isfinite(traded_value) & traded_value.ge(0)).all(axis=0)
        complete &= len(traded_value) == config["advSessions"]
        adv = adv.where(complete)
        eligible &= complete & adv.ge(config["minimumAdv20Krw"])
    m1 = momentum.where(eligible)
    persistence = formation_sign.where(eligible)
    # Rank only the common eligible cross-section, not the full-history panel.
    out["m1"] = m1
    out["m2"] = (m1.rank(pct=True) + persistence.rank(pct=True)) / 2
    out["m3"] = m1 / vol
    out["adv20"] = adv
    return out


def targets(features: pd.DataFrame, method: str, config: dict) -> pd.Series:
    eligible = features.dropna(subset=["m1", "m2", "m3"])
    if method == "baseline":
        return (
            pd.Series(1 / len(eligible), index=eligible.index)
            if len(eligible)
            else pd.Series(dtype=float)
        )
    ranked = eligible.sort_index().sort_values(method, ascending=False, kind="stable")
    return pd.Series(1 / config["topN"], index=ranked.head(config["topN"]).index)


def rebalance(
    holdings: pd.Series,
    cash: float,
    open_prices: pd.Series,
    last_close: pd.Series,
    weights: pd.Series,
    cost_rate: float,
    tolerance: float,
) -> tuple[pd.Series, float, dict]:
    """Sell first; unfilled sells remain held. Scale buys to available cash after costs.

    Requested dollars use pre-trade NAV. Actual costs are rate * absolute filled notional.
    Scaling buys, including their cost, prevents hidden borrowing at a fully invested target.
    A retained position without an open uses the preceding day's verified accounting mark
    solely to size other orders. It still requires its own current-day EOD valuation.
    """
    held = holdings[holdings > 0]
    symbols = held.index.union(weights.index)
    quotes = open_prices.reindex(symbols)
    fillable = np.isfinite(quotes) & quotes.gt(0)
    marks = quotes.where(fillable, last_close.reindex(symbols))
    invalid = held.index[
        ~(np.isfinite(marks.reindex(held.index)) & marks.reindex(held.index).gt(0))
    ]
    if len(invalid):
        raise DataBlocker("missing-held-open-and-prior-close", {"tickers": invalid.tolist()})
    current = held.reindex(symbols, fill_value=0) * marks.fillna(0)
    nav = cash + current.sum()
    desired = weights.reindex(symbols, fill_value=0) * nav
    requested = desired - current
    orders = requested.where(fillable, 0)
    sells = orders.clip(upper=0)
    cash_after_sells = cash - sells.sum() - cost_rate * sells.abs().sum()
    buys = orders.clip(lower=0)
    buy_total = buys.sum()
    buy_scale = (
        min(1.0, max(0.0, cash_after_sells) / (buy_total * (1 + cost_rate))) if buy_total else 1.0
    )
    fills = sells + buys * buy_scale
    fees = cost_rate * fills.abs().sum()
    new_cash = cash - fills.sum() - fees
    units = held.reindex(symbols, fill_value=0) + fills.div(quotes.where(fillable)).fillna(0)
    # Exact full exits have zero residual units. Never delete a holding using a quantity
    # epsilon: adjusted-price rescaling would change its economic meaning.
    units.loc[weights.reindex(symbols, fill_value=0).eq(0) & fillable] = 0.0
    if new_cash < -tolerance or (units < -tolerance).any():
        raise AssertionError("cash or long-only accounting violated")
    if abs((new_cash + (units * marks.fillna(0)).sum()) - (nav - fees)) > tolerance:
        raise AssertionError("trade accounting does not conserve value after explicit fees")
    return (
        units[units > 0],
        max(0.0, float(new_cash)),
        {
            "navBefore": float(nav),
            "cost": float(fees),
            "turnover": float(fills.abs().sum() / nav),
            "fills": fills[fills.abs() > tolerance],
            "unfilled": requested[(~fillable) & (requested.abs() > tolerance)],
            "buyScale": float(buy_scale),
        },
    )


def simulate(
    panel: Panel,
    config: dict,
    method: str,
    cost_bps: float,
    *,
    terminal=None,
    record_performance: bool = True,
    feature_builder=None,
) -> dict:
    frames = panel.frames
    dates = frames["adj_close"].index
    eligible_dates = dates[(dates >= config["devStart"]) & (dates <= config["devEnd"])]
    if eligible_dates.empty:
        raise DataBlocker("empty-development-window", {})
    holdings, cash = pd.Series(dtype=float), 1.0
    rows, orders, memberships = [], [], []
    last_close = pd.Series(dtype=float)
    pending_weights, pending_features, signal_date = pd.Series(dtype=float), None, None
    previous = None
    classifications = {}
    checked_sessions = 0
    risk_flags = {
        "long-only": True,
        "gross-exposure-at-most-one": True,
        "no-leveraged-or-inverse-etfs": True,
    }
    # The previous observed close can seed the first month's opening allocation.
    # Detect month changes at the current session: selection uses only the preceding date.
    for date in dates:
        if date > pd.Timestamp(config["devEnd"]):
            break
        # Classification is a last actually observed fact, separate from price filling.
        # Keep the source date; never modify the feature/universe frames with this state.
        for ticker, allowed in frames["allowed"].loc[date].dropna().items():
            classifications[ticker] = {"allowed": bool(allowed == 1), "asOf": str(date.date())}
        if date < pd.Timestamp(config["devStart"]):
            last_close = frames["adj_close"].loc[date]
            previous = date
            continue
        close = frames["adj_close"].loc[date]
        month_changed = previous is not None and date.to_period("M") != previous.to_period("M")
        turnover, cost = 0.0, 0.0
        if month_changed:
            signal_date = previous
            pending_features = (feature_builder or features_asof)(frames, signal_date, config)
            pending_weights = targets(pending_features, method, config)
            if record_performance:
                memberships.extend(
                    {
                        "signalDate": str(signal_date.date()),
                        "ticker": ticker,
                        "targetWeight": float(weight),
                    }
                    for ticker, weight in pending_weights.items()
                )
            try:
                holdings, cash, trade = rebalance(
                    holdings,
                    cash,
                    frames["adj_open"].loc[date],
                    last_close,
                    pending_weights,
                    cost_bps / 10000,
                    config["accountingTolerance"],
                )
            except DataBlocker as exc:
                raise DataBlocker(
                    str(exc),
                    {**exc.evidence, "date": str(date.date()), "performanceEmitted": False},
                ) from None
            turnover, cost = trade["turnover"], trade["cost"]
            for ticker, dollars in trade["fills"].items() if record_performance else []:
                adv = float(pending_features.loc[ticker, "adv20"])
                participation = (
                    (abs(dollars) / trade["navBefore"] * config["diagnosticAum"] / adv)
                    if np.isfinite(adv) and adv > 0
                    else None
                )
                orders.append(
                    {
                        "signalDate": str(signal_date.date()),
                        "fillDate": str(date.date()),
                        "ticker": ticker,
                        "filledNavFraction": dollars / trade["navBefore"],
                        "adv20": adv if np.isfinite(adv) else None,
                        "orderParticipation": participation,
                        "status": "filled",
                    }
                )
            for ticker, dollars in trade["unfilled"].items() if record_performance else []:
                orders.append(
                    {
                        "signalDate": str(signal_date.date()),
                        "fillDate": str(date.date()),
                        "ticker": ticker,
                        "requestedNavFraction": dollars / trade["navBefore"],
                        "status": "missing-open-buy-cash"
                        if dollars > 0
                        else "missing-open-sell-held",
                    }
                )
        # A payment disclosed during this day cannot finance its earlier opening trades.
        # Terminal marks live only in accounting; the original signal frames stay unchanged.
        if terminal is not None:
            holdings, cash, close = terminal.end_of_day(
                holdings, cash, close, date, config["accountingTolerance"], classifications
            )
        # Close is a valuation check after opening fills, never a condition for those fills.
        invalid_held = holdings.index[
            ~(np.isfinite(close.reindex(holdings.index)) & close.reindex(holdings.index).gt(0))
        ]
        if len(invalid_held):
            evidence = []
            for ticker in invalid_held:
                history = frames["adj_close"].loc[:date, ticker].dropna()
                related = [row for row in orders if row["ticker"] == ticker]
                evidence.append(
                    {
                        "ticker": ticker,
                        "date": str(date.date()),
                        "lastObservedDate": str(history.index[-1].date()),
                        **(
                            {
                                "lastObservedAdjustedClose": float(history.iloc[-1]),
                                "lastOrders": related[-2:],
                            }
                            if record_performance
                            else {}
                        ),
                    }
                )
            raise DataBlocker(
                "missing-held-close-no-documented-terminal-value",
                {
                    "method": method,
                    "costBps": cost_bps,
                    "rows": evidence,
                    "performanceEmitted": False,
                    "partialWindowMetricsComputed": False,
                    "resumeCondition": "A documented valuation/redemption event for held ETFs, "
                    "or separately approved change to the research envelope.",
                },
            )
        missing_classification = [t for t in holdings.index if t not in classifications]
        if missing_classification:
            raise DataBlocker(
                "missing-held-exposure-classification",
                {
                    "date": str(date.date()),
                    "tickers": missing_classification,
                    "performanceEmitted": False,
                },
            )
        gross = float((holdings * close.reindex(holdings.index)).sum())
        equity = cash + gross
        if not np.isfinite(equity) or equity <= 0:
            raise DataBlocker("nonpositive-or-nonfinite-equity", {"date": str(date.date())})
        risk_flags["long-only"] &= bool((holdings >= 0).all() and cash >= 0)
        risk_flags["gross-exposure-at-most-one"] &= (
            gross / equity <= 1 + config["accountingTolerance"]
        )
        risk_flags["no-leveraged-or-inverse-etfs"] &= bool(
            all(classifications[ticker]["allowed"] for ticker in holdings.index)
        )
        if record_performance:
            rows.append(
                {
                    "date": date,
                    "equity": equity,
                    "cashWeight": cash / equity,
                    "grossWeight": gross / equity,
                    "turnover": turnover,
                    "cost": cost,
                    "holdings": len(holdings),
                }
            )
        last_close, previous = close, date
        checked_sessions += 1
    if not record_performance:
        return {
            "status": "completed",
            "checkedSessions": checked_sessions,
            "performanceComputed": False,
            "terminalUses": terminal.trace if terminal is not None else [],
            "riskConstraints": [
                {"constraint": k, "within": bool(v)} for k, v in risk_flags.items()
            ],
        }
    return {
        "daily": pd.DataFrame(rows),
        "orders": orders,
        "memberships": memberships,
        "riskConstraints": [{"constraint": k, "within": bool(v)} for k, v in risk_flags.items()],
        "terminalUses": terminal.trace if terminal is not None else [],
    }
