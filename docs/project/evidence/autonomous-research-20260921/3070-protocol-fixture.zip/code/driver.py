
import argparse
import csv
import hashlib
import json
import math
import os
import sys
from datetime import date, datetime
from pathlib import Path


def dump(path, value):
    path.write_text(json.dumps(value, sort_keys=True, allow_nan=False) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows_contract(rows):
    if not isinstance(rows, list) or not rows:
        raise ValueError('empty-sample')
    previous = None
    for row in rows:
        if set(row) != {'date', 'observed_at', 'value'}:
            raise ValueError('fields-mismatch')
        day = date.fromisoformat(row['date'])
        instant = datetime.fromisoformat(row['observed_at'])
        if day.isoformat() != row['date'] or instant.tzinfo is None or instant.utcoffset() is None:
            raise ValueError('date-contract')
        if instant.date() != day or (previous is not None and day <= previous):
            raise ValueError('date-order')
        if type(row['value']) not in (int, float) or not math.isfinite(row['value']):
            raise ValueError('non-finite-sample')
        previous = day
    return rows


def qualification_document(manifest, rows):
    rows_contract(rows)
    for invalid in ([], [dict(rows[0], value=float('nan'))], [dict(rows[0], value=float('inf'))]):
        try:
            rows_contract(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError('qualification-negative-probe-failed')
    if json.loads(json.dumps(rows, allow_nan=False)) != rows:
        raise AssertionError('json-roundtrip')
    start = date.fromisoformat(manifest['plan']['development']['start'])
    if any(date.fromisoformat(row['date']) >= start for row in rows):
        raise ValueError('warmup-only')
    return {
        'schema_version':1, 'kind':'adaptive_qualification',
        'trial_id':manifest['trial_id'], 'plan_digest':manifest['plan_digest'],
        'code_commit':manifest['plan']['code_commit'], 'config_files':manifest['plan']['config_files'],
        'input_files':{'warmup/rows.json':manifest['plan']['input_files']['warmup/rows.json']},
        'sample_count':len(rows), 'json_dates':[row['date'] for row in rows],
        'json_datetimes':[row['observed_at'] for row in rows],
        'typed_schema':{'date':'date','observed_at':'datetime','value':'float'},
        'primary_unit':'fraction-per-year', 'empty_sample_rejected':True,
        'non_finite_rejected':True, 'json_roundtrip_passed':True,
        'performance_read':False, 'sealed_read':False,
    }


def write_result(manifest, rows, output, isolation):
    rows_contract(rows)
    if len(rows) < 2:
        raise ValueError('dated-series-requires-two-observations')
    files = {}
    for cost in ('base', 'stress'):
        path = output / (cost + '.csv')
        with path.open('w', newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(['date', 'net_return'])
            writer.writerows((row['date'], 0.0) for row in rows)
        files[path.name] = sha(path)
    dump(output / 'isolation.json', isolation)
    files['isolation.json'] = sha(output / 'isolation.json')
    references = {cost:{'path':cost+'.csv', 'sha256':files[cost+'.csv'],
                        'frequency':'monthly', 'unit':'fraction-per-period'} for cost in ('base', 'stress')}
    value = {
        'schema_version':1, 'kind':'adaptive_result', 'trial_id':manifest['trial_id'],
        'plan_digest':manifest['plan_digest'], 'code_commit':manifest['plan']['code_commit'],
        'metrics':{
            'primary':{'metric':'stress-net-absolute-cagr','direction':'maximize',
                       'unit':'fraction-per-year','value':0.0},
            'risks':{'max_drawdown':0.0}, 'sample_count':len(rows),
            'sample_window':manifest['plan']['development'],
        },
        'base_returns':references['base'], 'stress_returns':references['stress'], 'output_files':files,
    }
    dump(output / 'result.json', value)
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('qualify', 'evaluate'))
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    from model import FIXTURE_REVISION
    assert FIXTURE_REVISION == 2, 'patched-committed-code-not-consumed'
    assert Path.cwd() == Path('/code') and Path.home() == Path('/home/sandbox')
    assert json.loads(args.config.read_text()) == {'fixture_only':True}
    assert not any(name in os.environ for name in (
        'RESEARCH_SANDBOX_SMOKE_PROFILE', 'AWS_SECRET_ACCESS_KEY', 'OPENAI_API_KEY', 'SLACK_BOT_TOKEN',
    ))
    for absent in ('/code/.git', '/code/.env', '/code/history/prior.json', '/home/achii', '/root/.ssh', '/inputs/sealed'):
        assert not Path(absent).exists(), 'unapproved-path-visible'
    visible = sorted(path.relative_to('/inputs').as_posix() for path in Path('/inputs').rglob('*') if path.is_file())
    expected = ['__contract__/manifest.json', 'warmup/rows.json']
    if args.action == 'evaluate':
        expected.append('dev/rows.json')
    assert visible == sorted(expected), 'phase-input-mount-mismatch'
    for readonly in (Path('/code/driver.py'), Path('/code/model.py'), Path('/inputs/warmup/rows.json')):
        try:
            with readonly.open('a') as stream:
                stream.write('forbidden-write')
        except OSError:
            pass
        else:
            raise AssertionError('readonly-mount-writable')
    manifest = json.loads(args.manifest.read_text())
    isolation = {
        'fixture_only':True, 'phase':args.action, 'python':sys.version,
        'network_namespace':os.readlink('/proc/self/ns/net'), 'pid_namespace':os.readlink('/proc/self/ns/pid'),
        'visible_inputs':visible, 'patched_fixture_revision':FIXTURE_REVISION,
        'history_hidden':True, 'home_hidden':True, 'parent_environment_hidden':True,
        'code_readonly':True, 'inputs_readonly':True,
    }
    if args.action == 'qualify':
        rows = json.loads(Path('/inputs/warmup/rows.json').read_text())
        dump(args.output / 'qualification.json', qualification_document(manifest, rows))
        dump(args.output / 'isolation.json', isolation)
    else:
        rows = json.loads(Path('/inputs/dev/rows.json').read_text())
        write_result(manifest, rows, args.output, isolation)


if __name__ == '__main__':
    main()
