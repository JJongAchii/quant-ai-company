"""Engineering baseline only; replace inside the approved program scope."""

def weights(history, config):
    latest = max(row["date"] for row in history)
    tickers = sorted(row["ticker"] for row in history if row["date"] == latest)
    return {ticker: 1 / len(tickers) for ticker in tickers}

def predict(history, config):
    latest = max(row["date"] for row in history)
    tickers = sorted(row["ticker"] for row in history if row["date"] == latest)
    scores = {}
    for ticker in tickers:
        prices = [row["adj_close"] for row in history if row["ticker"] == ticker]
        if len(prices) < 2:
            raise ValueError("prediction_warmup_missing")
        scores[ticker] = prices[-1] / prices[-2] - 1
    return scores

# Synthetic qualification candidate revision.
